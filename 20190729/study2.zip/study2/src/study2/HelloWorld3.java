package study2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.*;
import java.util.*;


public class HelloWorld3  extends HttpServlet{

	//HttpServlet - Source - override service(HttpServletRequest arg0, HttpServletResponse arg1) Ŭ��
	@Override
	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// protected -> public �������̸� error�ȳ�
		System.out.println("Hello World3!");

		//run - run as - run on server - close

		String theTime = null;
		List<BangMyungVO> ls = null;
		try{
			//WebContent/WEB-INF/lib�� ojdbc.jar�ְ�
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521/XE","HR","HR");
			System.out.println(conn);
			
			Statement stmt = conn.createStatement();
//			String sql = "select sysdate from dual";
			String sql = "select no, gul, the_time from bangmyung_t";
			
			ResultSet rs = stmt.executeQuery(sql);

			ls = new ArrayList<BangMyungVO>();
			while(rs.next()){
//				theTime = rs.getString(1);
				BangMyungVO vo = new BangMyungVO();
				vo.setNo(rs.getInt(1));
				vo.setGul(rs.getString(2));
				vo.setTheTime(rs.getString(3));
				
				ls.add(vo);
			}
			
			/* 
			 * table -> class
			 * field -> property
			 * record -> instance
			 */
			
			
			rs.close();
			stmt.close();
			conn.close();
			
		}catch(Exception e){
			//������ �� ������ �������ؼ� ����� �ش�.
			e.printStackTrace();
		}
		//�ѱ۱����� �̷��� (������ �ڵ�)
		response.setContentType("text/html;charset=euc-kr");
		
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<body>");
//		out.println("Hello World 2 : ^^*");

		int random = 0;
		out.println("<table border=\"1\" cellspacing=\"1\" cellpadding=\"50\">");
		for(BangMyungVO v: ls){
			random = (int)(Math.random()*1000000);
			System.out.println("<tr bgColor=\"#"+random+"\">");
			out.println("<tr bgColor=\"#"+random+"\">");
			out.println("<td>");
			out.println(v.getNo());
			out.println("</td>");
			out.println("<td>");
			out.println(v.getGul());
			out.println("</td>");
			out.println("<td>");
			out.println(v.getTheTime());
			out.println("</td>");
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("</html>");
		out.close();
	}
	
	//server ��Ŭ�� - add & remove - study2


}
