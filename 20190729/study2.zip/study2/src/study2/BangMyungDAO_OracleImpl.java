package study2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class BangMyungDAO_OracleImpl implements BangMyungDAO{

	@Override
	public void add(BangMyungVO vo) throws Exception {
		Connection conn = null;
		Statement stmt = null;		
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521/XE","HR","HR");
			System.out.println(conn);
			
			stmt = conn.createStatement();
			

			String sql="insert into bangmyung_t values (seq_bangmyung.nextval, '"+vo.getGul()+"',sysdate)";
			stmt.executeUpdate(sql);

		}catch(Exception e){ throw e;
		}finally{
			try {
				if(stmt!=null) stmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}

	@Override
	public List<BangMyungVO> findAll() throws Exception {
		List<BangMyungVO> ls = new ArrayList<BangMyungVO>();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521/XE","HR","HR");
			System.out.println(conn);
			
			stmt = conn.createStatement();

			String sql="select no, gul, the_time from bangmyung_t order by no desc";
			rs = stmt.executeQuery(sql);
			
            while(rs.next()){
                BangMyungVO vo = new BangMyungVO();
                vo.setNo(rs.getInt(1));
                vo.setGul(rs.getString(2));
                vo.setTheTime(rs.getString(3));

                ls.add(vo);
            }

		}catch(Exception e){ throw e;
		}finally{
			try {
				if(stmt!=null) stmt.close();
				if(conn!=null) conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return ls;
	}

}
