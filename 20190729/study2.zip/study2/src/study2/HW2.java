package study2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class HW2 extends HttpServlet{

	@Override
	public void service(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		PrintWriter out = res.getWriter();
		out.println("<html>");
		out.println("<body>");
		out.println("<table cellpadding=\"15\">");
		
		for(int i=1;i<=9;i++){
			out.println("<tr>");
			for(int j=1;j<=9;j++){
				String rgb_str = "FF";
				for(int k=1;k<3;k++){
					rgb_str=rgb_str+String.format("%02X",(int)(Math.random()*255));
				}
				System.out.println(rgb_str);
				out.println("<td align=\"center\" bgcolor=#"+rgb_str+">");
				out.println(i+" * "+j+" = "+i*j);
				out.println("<td>");
			}
			out.println("</tr>");
		}
		out.println("</table>");
		out.println("</body>");
		out.println("</html>");
		
	}

}
