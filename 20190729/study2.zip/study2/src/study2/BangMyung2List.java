package study2;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BangMyung2List extends HttpServlet {

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//		BangMyungDAO dao = new BangMyungDAO_KaraImpl();
		BangMyungDAO dao = new BangMyungDAO_OracleImpl();
		List<BangMyungVO> ls = null;
		try {
			ls = dao.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		response.setContentType("text/html;charset=euc-kr");
		
		//http://192.168.2.58:8081/study2/bangmyung_list
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head>"+
		  "<title>Bootstrap Example</title>"+
		  "<meta charset=\"utf-8\">"+
		  "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"+
		  "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css\">"+
		  "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js\"></script>"+
		  "<script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js\"></script>"+
		"</head>");
		out.println("<body>");
		out.println("<div class=\"container\">");
		out.println("<table border=\"1\" cellspacing=\"1\" cellpadding=\"50\" class=\"table\">"+
					"<thead>"+
						"<tr>"+
							"<th>No</th>"+
							"<th>Gul</th>"+
							"<th>TheTime</th>"+
							"</tr>"+
	      			"</thead>"+	
					"<tbody>");
		for(BangMyungVO v: ls){
			out.println("<tr>");
			out.println("<td>");
			out.println(v.getNo());
			out.println("</td>");
			out.println("<td>");
			out.println(v.getGul());
			out.println("</td>");
			out.println("<td>");
			out.println(v.getTheTime());
			out.println("</td>");
			out.println("</tr>");
		}
		out.println("</tbody></table>");

		out.println("<br/>");
		out.println("<br/>");
		out.println("<form method=\"post\" action=\"bangmyung_add2\" >");
		out.println("	<input type=\"text\" size=\"50\" name=\"gul\" class=\"form-control\">");
		out.println("	<input type=\"submit\" class=\"btn btn-default\" >");
		out.println("</form>");

		out.println("</div>");
		out.println("</html>");
		out.close();
		
	}

}
